﻿using System.Web.UI;

namespace Nextech.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}