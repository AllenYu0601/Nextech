﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nextech
{
    public class HackerProperty
    {
        public string By { get; set; }
        public string Title { get; set; }
        public string Url { get; set; }
    }
}